package com.trabajoPractico.trabajoPractico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoPracticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoPracticoApplication.class, args);
	}

}
