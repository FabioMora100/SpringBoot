package com.argentina.argentina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArgentinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
